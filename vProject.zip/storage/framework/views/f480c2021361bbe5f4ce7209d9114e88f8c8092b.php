<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Clientes</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="css/style.css">
        <script src="js/jquery-3.1.1.min.js"></script>
    </head>
    <body>
       <?php echo $__env->make('layouts.menuNavBar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       
    <div id="tableContent">
        <h2>Ventas Activas</h2>
        <a href="nuevaVenta">Nueva Venta</a>
        <table>
        <thead>
            <tr>
                <th>Folio Venta</th>
                <th>Clave Cliente</th>
                <th>Nombre</th>
                <th>Total</th>
                <th>Fecha</th>
                <th>Estatus</th>
            </tr>
        </thead>
        <tbody>
        <?php if(isset($ventas)): ?>
            <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
               <td><?php echo e($venta->idVenta); ?></td>
               <td><?php echo e($venta->idCliente); ?></td>
               <td><?php echo e($venta->nombre); ?> <?php echo e($venta->aPaterno); ?> <?php echo e($venta->aMaterno); ?></td>
               
               <td><?php echo e($venta->total); ?></td>
               <td><?php echo e($venta->fecha); ?></td>
               <td><?php if($venta->estatus == 0): ?> Pendiente <?php else: ?> Pagado <?php endif; ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php endif; ?>
        </tbody>
        </table>
    </div>
    </body>
</html>
