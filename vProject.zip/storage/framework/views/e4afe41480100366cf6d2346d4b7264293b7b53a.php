<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Articulos</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="css/style.css">
        <script src="js/jquery-3.1.1.min.js"></script>
    </head>
    <body>
       <?php echo $__env->make('layouts.menuNavBar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       
    <div id="tableContent">
        <h2>Articulos Registrados</h2>
        <a href="agregarArticulo">Nuevo Articulo</a>
        <table>
        <thead>
            <tr>
                <th>Clave</th>
                <th>Descripcion</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php if(isset($articulos)): ?>
            <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td><?php echo e($articulo->id); ?></td>
                <td><?php echo e($articulo->descripcion); ?></td>
                <td><a href="editarArticulo?clave=<?php echo e($articulo->id); ?>">Editar</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php endif; ?>
        </tbody>
        </table>
    </div>
    </body>
</html>
