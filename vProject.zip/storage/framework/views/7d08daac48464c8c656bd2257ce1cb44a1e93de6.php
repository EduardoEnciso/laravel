<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Clientes</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="css/style.css">
        <script src="js/jquery-3.1.1.min.js"></script>
        <script src="js/js.js"></script>

    </head>
    <body>
       <?php echo $__env->make('layouts.menuNavBar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       
    <div id="tableContent">
        <h2>Clientes Registrados</h2>
        <a href="agregarCliente">Nuevo Cliente</a>
        <table>
        <thead>
            <tr>
                <th>Clave</th>
                <th>Nombre</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php if(isset($clientes)): ?>
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td><?php echo e($cliente->id); ?></td>
                <td><?php echo e($cliente->nombre); ?> <?php echo e($cliente->aPaterno); ?> <?php echo e($cliente->aMaterno); ?></td>
                <td><a href="editarCliente?clave=<?php echo e($cliente->id); ?>">Editar</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php endif; ?>
        </tbody>
        </table>
    </div>
    </body>
</html>
