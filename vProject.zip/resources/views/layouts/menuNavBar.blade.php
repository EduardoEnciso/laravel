        <ul id="nav"> 
          <li class="dropdown">
            <a href="inicio" class="dropbtn">Inicio</a>
            <div class="dropdown-content">
              <a href="ventas">Ventas</a>
              <a href="clientes">Clientes</a>
              <a href="articulos">Articulos</a>
              <a href="configuracion">Configuracion</a>
            </div>
          </li>
          <li class="dropdown" style="float: right; margin-right: 8%;"><a id="fecha"></a></li>
        </ul>


